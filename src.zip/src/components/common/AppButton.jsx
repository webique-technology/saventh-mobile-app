export default function AppButton({
  children,
  variant = "primary",
  className = "",
  ...props
}) {
  return (
    <button className={`sav-btn sav-btn--${variant} ${className}`} {...props}>
      {children}
    </button>
  );
}
